package es.cfc.business;

import java.util.List;

import es.cfc.models.Producto;
import es.cfc.persistence.ItfzProductosDAO;
import es.cfc.persistence.ProductosDAO;

public class ProductosBS {
	
	private ItfzProductosDAO dao = new ProductosDAO();
	
	public List<Producto> consultarTodos(){
		return dao.consultarTodos();
	}
	
	public boolean altaProducto(Producto nuevo) {
		return dao.altaProducto(nuevo);
	}
	
	public Producto buscarPorId(int id) {
		return dao.buscarPorId(id);
	}
	
	public List<Producto> buscarPorDescripcion(String descripcion){
		return dao.buscarPorDescripcion(descripcion);
	}
	
	public boolean eliminarProducto(int id) {
		return dao.eliminarProducto(id);
	}
	public boolean cambiarPrecio(int id, double nuevo) {
		return dao.cambiarPrecio(id, nuevo);
	}

}
