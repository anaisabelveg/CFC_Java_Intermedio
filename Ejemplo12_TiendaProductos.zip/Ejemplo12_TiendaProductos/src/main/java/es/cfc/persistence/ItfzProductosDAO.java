package es.cfc.persistence;

import java.util.List;

import es.cfc.models.Producto;

public interface ItfzProductosDAO {
	
	List<Producto> consultarTodos();
	boolean altaProducto(Producto nuevo);
	Producto buscarPorId(int id);
	List<Producto> buscarPorDescripcion(String descripcion);
	boolean eliminarProducto(int id);
	boolean cambiarPrecio(int id, double nuevo);

}
