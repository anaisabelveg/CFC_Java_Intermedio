package es.cfc;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Genericos {

	public static void main(String[] args) {
		
		Set<String> nombres = new HashSet<String>();
		nombres.add("Luis");
		nombres.add("Jorge");
		nombres.add("Juan");
		nombres.add("Belen");
		nombres.add("Juan");
		// error de compilacion
		//nombres.add(7);
		
		for (String nombre : nombres) {
			System.out.println(nombre.toUpperCase());
		}
		
		// En genericos solo se permite utilizar clases no tipos primitivos
		List<Integer> numeros = new ArrayList<Integer>();
		numeros.add(8);
		numeros.add(4);
		numeros.add(2);
		numeros.add(7);
		
		Iterator<Integer> it = numeros.iterator();
		while (it.hasNext()) {
			System.out.println(it.next());
		}
		
		
		Map<String, Double> notas = new HashMap<String, Double>();
		notas.put("Matematicas", 7.3);
		notas.put("Lengua", 5.1);
		notas.put("Historia", 8.2);
		notas.put("Fisica", 4.3);
		notas.put("Ingles", 9.7);
		
		notas.put("Fisica", 5.8);
		
		System.out.println(notas);
		

	}
}






