package es.cfc;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class AppMain {

	public static void main(String[] args) {
		// Set -> NO duplicados, No orden de entrada
		// List -> SI duplicados, SI orden de entrada
		
		Set set = new HashSet();
		set.add("Hola");
		set.add(78);
		set.add('A');
		set.add(true);
		set.add("Hola");
		
		System.out.println(set);
		
		for (Object object : set) {
			
		}
		
		List lista = new ArrayList();
		lista.add("Hola");
		lista.add(78);
		lista.add('A');
		lista.add(true);
		lista.add("Hola");
		
		System.out.println(lista);
		
		
		Map mapa = new HashMap();
		mapa.put("Pepito", 1);
		mapa.put(4, 8);
		mapa.put(true, 'B');
		mapa.put("Pepito", 49);
		
		System.out.println(mapa);
		//syso + ctrl + space
		
		// recuperar un valor por su clave
		System.out.println(mapa.get("Pepito"));
		
		// values() -> me devuelve todos los valores del mapa
		System.out.println(mapa.values());
		
		// entrySet() -> devuelve todas las entradas del mapa
		System.out.println(mapa.entrySet());
		
		// keySet() -> devuelve todas las claves del mapa
		System.out.println(mapa.keySet());
	

	}

}
