package es.cfc.persistence;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import es.cfc.models.Producto;

public class ProductosDAO implements ItfzProductosDAO{
	
	private Connection conexion;
	
	@Override
	public List<Producto> consultarTodos() {
		List<Producto> lista = new ArrayList<Producto>();
		
		try {
			abrirConexion();
			String sql = "select * from PRODUCTOS";
			Statement stm = conexion.createStatement();
			ResultSet rs = stm.executeQuery(sql);
			while (rs.next()) {
				lista.add(new Producto(rs.getInt("ID"),
						rs.getString("DESCRIPCION"),
						rs.getDouble("PRECIO")));
			}
		} catch (Exception e) {
			System.out.println("Error al consultar todos los productos");
			e.printStackTrace();
		} finally {
			cerrarConexion();
		}
		
		return lista;
	}

	@Override
	public boolean altaProducto(Producto nuevo) {
		boolean insertado = false;
		
		try {
			abrirConexion();
			String sql = "insert into PRODUCTOS values (?,?,?)";
			PreparedStatement pst = conexion.prepareStatement(sql);
			pst.setInt(1,nuevo.getId());
			pst.setString(2, nuevo.getDescripcion());
			pst.setDouble(3, nuevo.getPrecio());
			int registros = pst.executeUpdate();
			if (registros == 1)
				insertado = true;
		} catch (Exception e) {
			System.out.println("Error al insertar producto " + nuevo);
			e.printStackTrace();
		} finally {
			cerrarConexion();
		}
		
		return insertado;
	}

	@Override
	public Producto buscarPorId(int id) {
		Producto encontrado = null;
		
		try {
			abrirConexion();
			String sql = "select * from PRODUCTOS where ID=?";
			PreparedStatement pst = conexion.prepareStatement(sql);
			pst.setInt(1,id);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				encontrado = new Producto(rs.getInt("ID"),
						rs.getString("DESCRIPCION"),
						rs.getDouble("PRECIO"));
			}
		} catch (Exception e) {
			System.out.println("Error al buscar el producto con id " + id);
			e.printStackTrace();
		} finally {
			cerrarConexion();
		}
		
		return encontrado;
	}

	@Override
	public List<Producto> buscarPorDescripcion(String descripcion) {
		List<Producto> lista = new ArrayList<Producto>();
		try {
			abrirConexion();
			String sql = "select * from PRODUCTOS where DESCRIPCION like ? ";
			PreparedStatement pst = conexion.prepareStatement(sql);
			pst.setString(1, "%"+descripcion+"%");
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				lista.add(new Producto(rs.getInt("ID"),
						rs.getString("DESCRIPCION"),
						rs.getDouble("PRECIO")));
			}
		} catch (Exception e) {
			System.out.println("Error al buscar por descripcion " + descripcion);
			e.printStackTrace();
		} finally {
			cerrarConexion();
		}
		return lista;
	}

	@Override
	public boolean eliminarProducto(int id) {
		boolean eliminado = false;
		
		try {
			abrirConexion();
			String sql = "delete from PRODUCTOS where ID=?";
			PreparedStatement pst = conexion.prepareStatement(sql);
			pst.setInt(1, id);
			int registros = pst.executeUpdate();
			if (registros == 1) eliminado = true;
		} catch (Exception e) {
			System.out.println("Error al eliminar el producto con id " + id);
			e.printStackTrace();
		} finally {
			cerrarConexion();
		}
		
		return eliminado;
	}

	@Override
	public boolean cambiarPrecio(int id, double nuevo) {
		boolean modificado = false;
		
		try {
			abrirConexion();
			String sql = "update PRODUCTOS set PRECIO = ? where ID = ?";
			PreparedStatement pst = conexion.prepareStatement(sql);
			pst.setDouble(1, nuevo);
			pst.setInt(2,id);
			int registros = pst.executeUpdate();
			if (registros == 1)
				modificado = true;
		} catch (Exception e) {
			System.out.println("Error al modificar el producto con id " + id);
			e.printStackTrace();
		} finally {
			cerrarConexion();
		}
		
		return modificado;
	}
	
	private void abrirConexion() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/Tienda",
					"root","");
		} catch (ClassNotFoundException e) {
			System.out.println("Error al cargar el driver");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("Error al abrir la conexion");
			e.printStackTrace();
		}

	}
	
	private void cerrarConexion() {
		try {
			conexion.close();
		} catch (SQLException e) {
			System.out.println("Error al cerrar la conexion");
			e.printStackTrace();
		}
	}

	

}
