package es.cfc.business;

import es.cfc.utils.DividirException;

public class Operaciones {
	
	public double dividir(int num1, int num2) throws DividirException  {
		
		if (num2 == 0) {
			// lanzar nuestra excepcion
			throw new DividirException("No se puede dividir por cero");
		}
		
		return num1 / num2;
	}

}
