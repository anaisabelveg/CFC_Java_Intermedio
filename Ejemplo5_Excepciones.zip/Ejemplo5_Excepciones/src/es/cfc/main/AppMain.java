package es.cfc.main;

import es.cfc.business.Operaciones;
import es.cfc.utils.DividirException;

public class AppMain {

	public static void main(String[] args)  {
		
		int suma = 0;
		int numero = 0;
		
		for (String dato : args) {
			
			try {
				// Aqui ponemos las lineas que puedan generar error 	
				numero = Integer.parseInt(dato);
			} catch (NumberFormatException ex) {
				numero = 0;
				System.out.println(ex.getMessage());
				ex.printStackTrace();
			} catch (Exception e) {
				System.out.println("Ha ocurrido otro error");
			} finally {
				// Todo lo que pongamos en este bloque
				// se ejecuta siempre haya excepcion o no
				// cerrar un recurso
				// liberar una conexion
				// ....
			}
			
			//suma = suma + numero;
			suma += numero;
		}
		
		System.out.println("Resultado: " + suma);
		
		
		Operaciones operaciones = new Operaciones();
		try {
			operaciones.dividir(7, 2);
		} catch (DividirException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// Si la DividirException es una RuntimeExcepcion no obliga a manejar excepcion
		operaciones.dividir(8, 0);

	}

}
