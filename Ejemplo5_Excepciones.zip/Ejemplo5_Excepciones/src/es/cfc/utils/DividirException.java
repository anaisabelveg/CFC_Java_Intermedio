package es.cfc.utils;

public class DividirException extends RuntimeException{
	
	public DividirException(String mensaje) {
		super(mensaje);
	}

}
