package es.cfc.models;

public class Profesional extends Contacto {

	private String empresa;

	public Profesional() {
		// TODO Auto-generated constructor stub
	}

	public Profesional(int id, String nombre, long telefono, char sexo, String empresa) {
		super(id, nombre, telefono, sexo);
		this.empresa = empresa;
	}

	public String getEmpresa() {
		return empresa;
	}

	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}

	@Override
	public String toString() {
		return "Profesional [empresa=" + empresa + ", toString()=" + super.toString() + "]";
	}

}
