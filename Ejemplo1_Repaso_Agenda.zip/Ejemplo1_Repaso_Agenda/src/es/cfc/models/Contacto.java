package es.cfc.models;

// Una clase encapsulada tiene todas sus propiedades como privadas
// y se accede a ellas a través de get y set publicos
public class Contacto {
	
	// Propiedades, atributos, caracteristicas
	private int id;
	private String nombre;
	private long telefono;
	private char sexo;
	
	// Constructor por defecto, conviene siempre tenerlo
	public Contacto() {
		// TODO Auto-generated constructor stub
	}
	
	public Contacto(int id, String nombre, long telefono, char sexo) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.telefono = telefono;
		this.sexo = sexo;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public long getTelefono() {
		return telefono;
	}

	public void setTelefono(long telefono) {
		this.telefono = telefono;
	}

	public char getSexo() {
		return sexo;
	}

	public void setSexo(char sexo) {
		this.sexo = sexo;
	}

	@Override
	public String toString() {
		return "Contacto [id=" + id + ", nombre=" + nombre + ", telefono=" + telefono + ", sexo=" + sexo + "]";
	}
	
	
	

}
