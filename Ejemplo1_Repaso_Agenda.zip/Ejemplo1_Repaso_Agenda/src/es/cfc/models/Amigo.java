package es.cfc.models;

public class Amigo extends Contacto{
	
	private String apodo;
	
	public Amigo() {
		// TODO Auto-generated constructor stub
	}

	public Amigo(int id, String nombre, long telefono, char sexo, String apodo) {
		super(id, nombre, telefono, sexo);
		this.apodo = apodo;
	}

	public String getApodo() {
		return apodo;
	}

	public void setApodo(String apodo) {
		this.apodo = apodo;
	}

	@Override
	public String toString() {
		return "Amigo [apodo=" + apodo + ", toString()=" + super.toString() + "]";
	}

	


}
