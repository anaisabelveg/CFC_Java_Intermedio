package es.cfc.business;

import es.cfc.models.Contacto;

public class Agenda {

	private Contacto misContactos[] = new Contacto[10];
	private static int contador = 0;

	public Contacto[] verTodos() {
		return misContactos;
	}

	public void agregarContacto(Contacto contacto) {

		if (contador < 10) {
			misContactos[contador] = contacto;
			contador++;
		} else {
			System.out.println("No se admiten mas de 10 contactos");
		}
	}

	public Contacto buscar(String nombre) {
		Contacto encontrado = null;

		for (Contacto aux : misContactos) {
			if (aux != null) {
				if (nombre.equals(aux.getNombre())) {
					encontrado = aux;
					break;
				}
			}
		}

		return encontrado;
	}

}
