package es.cfc.web;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

/**
 * Application Lifecycle Listener implementation class ListenerApplication
 *
 */
@WebListener
public class ListenerApplication implements ServletContextListener {

	public void contextInitialized(ServletContextEvent sce)  { 
        // Recuperar el contexto de la aplicacion
		ServletContext ctxApp = sce.getServletContext();
		ctxApp.setAttribute("sinIVA", "Mañana dia sin IVA");
		System.out.println("Se ha creado el contexto de la aplicacion");
    }
	
    public void contextDestroyed(ServletContextEvent sce)  { 
         System.out.println("Se va a destruir el contexto de la aplicacion");
    }

	
}
