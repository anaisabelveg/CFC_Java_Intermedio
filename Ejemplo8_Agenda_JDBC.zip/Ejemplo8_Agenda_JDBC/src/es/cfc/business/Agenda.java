package es.cfc.business;

import java.util.List;

import es.cfc.models.Contacto;
import es.cfc.persistence.AgendaDAO;

public class Agenda {
	
	private AgendaDAO dao = new AgendaDAO();

	
	public List<Contacto> verTodos() {
		return dao.consultarTodos();
	}

	public void agregarContacto(Contacto contacto) {
		dao.altaContacto(contacto);
	}

	public Contacto buscar(String nombre) {
		return dao.buscarContacto(nombre);
	}

}
