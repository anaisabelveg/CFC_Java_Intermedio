package es.cfc.persistence;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import es.cfc.models.Amigo;
import es.cfc.models.Contacto;
import es.cfc.models.Profesional;

public class AgendaDAO {
	
	private Connection conexion;
	
	public Contacto buscarContacto(String nombre){
		Contacto encontrado = null;
		
		try {
			abrirConexion();
			
			String sql = "select * from Contactos where NOMBRE = ?";
			PreparedStatement pst = conexion.prepareStatement(sql);
			pst.setString(1, nombre);
			ResultSet rs = pst.executeQuery();
			
			if (rs.next()) {
				
				if (rs.getString("APODO") != null) {
					encontrado = new Amigo(rs.getInt("ID"), 
							rs.getString("NOMBRE"), 
							rs.getLong("TELEFONO"), 
							rs.getString("SEXO").charAt(0), 
							rs.getString("APODO"));
				} else {
					encontrado = new Profesional(rs.getInt("ID"), 
							rs.getString("NOMBRE"), 
							rs.getLong("TELEFONO"), 
							rs.getString("SEXO").charAt(0), 
							rs.getString("EMPRESA"));
				}			
			}
			
		} catch (Exception e) {
			System.out.println("Error al buscar el contacto " + nombre);
			e.printStackTrace();
		} finally {
			cerrarConexion();
		}
		
		return encontrado;
	}
	
	public List<Contacto> consultarTodos(){
		List<Contacto> lista = new ArrayList<Contacto>();
		
		try {
			abrirConexion();
			
			String sql = "select * from Contactos";
			Statement stm = conexion.createStatement();
			ResultSet rs = stm.executeQuery(sql);
			
			while (rs.next()) {
				
				if (rs.getString("APODO") != null) {
					lista.add(new Amigo(rs.getInt("ID"), 
							rs.getString("NOMBRE"), 
							rs.getLong("TELEFONO"), 
							rs.getString("SEXO").charAt(0), 
							rs.getString("APODO")));
				} else {
					lista.add(new Profesional(rs.getInt("ID"), 
							rs.getString("NOMBRE"), 
							rs.getLong("TELEFONO"), 
							rs.getString("SEXO").charAt(0), 
							rs.getString("EMPRESA")));
				}
				
			}
			
		} catch (Exception e) {
			System.out.println("Error al consultar todos los contactos");
			e.printStackTrace();
		} finally {
			cerrarConexion();
		}
		
		return lista;
	}
	
	public void altaContacto(Contacto contacto) {
		try {
			abrirConexion();
			
			String sql = "";
			
			if (contacto instanceof Amigo) {
				sql = "insert into Contactos (ID,NOMBRE,TELEFONO,SEXO,APODO) values (?,?,?,?,?)";
			} else {
				sql = "insert into Contactos (ID,NOMBRE,TELEFONO,SEXO,EMPRESA) values (?,?,?,?,?)";
			}
			PreparedStatement pst = conexion.prepareStatement(sql);
			pst.setInt(1, contacto.getId());
			pst.setString(2, contacto.getNombre());
			pst.setLong(3, contacto.getTelefono());
			pst.setString(4, String.valueOf(contacto.getSexo()));
			
			if (contacto instanceof Amigo) {
				pst.setString(5, ((Amigo)contacto).getApodo());
			} else {
				pst.setString(5, ((Profesional)contacto).getEmpresa());
			}
			
			pst.executeUpdate();
			
		} catch (Exception e) {
			System.out.println("Error al crear contacto " + contacto);
			e.printStackTrace();
		} finally {
			cerrarConexion();
		}
	}
	
	private void abrirConexion() {
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/AgendaDB", "root", "");
		} catch (ClassNotFoundException e) {
			System.out.println("Error al cargar el driver");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("Error al abrir la conexion");
			e.printStackTrace();
		}
		
	}
	
	private void cerrarConexion() {
		try {
			conexion.close();
		} catch (SQLException e) {
			System.out.println("Error al cerrar la conexion");
			e.printStackTrace();
		}
	}

}
