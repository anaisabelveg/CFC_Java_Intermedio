package es.cfc.main;

import es.cfc.business.Agenda;
import es.cfc.models.Amigo;
import es.cfc.models.Contacto;
import es.cfc.models.Profesional;

public class AppMain {

	public static void main(String[] args) {
		
		Agenda agenda = new Agenda();
		
		// Crear contactos y agregarlos a la agenda
		
//		Amigo maria = new Amigo();
//		maria.setId(1);
//		maria.setNombre("Maria");
//		maria.setSexo('M');
//		maria.setTelefono(616111111L);
//		maria.setApodo("Mery");
//		
//		agenda.agregarContacto(maria);
//		
//		Profesional juan = new Profesional(2, "Juan", 616222222L, 'H', "Indra");
//		
//		agenda.agregarContacto(juan);
//		
//		agenda.agregarContacto(new Amigo(3, "Luis", 616333333L, 'H', "Luisito"));
//		
//		agenda.agregarContacto(new Amigo(4, "Antonio", 616444444L, 'H', "Toño"));
//		
//		agenda.agregarContacto(new Profesional(5, "Laura", 616555555L, 
//				'M',"Laura, S.A."));
		
		// Mostrar todos los contactos
		for(Contacto c: agenda.verTodos()) {
			System.out.println(c);
		}
		
		// Buscar a Luis
		if (agenda.buscar("Antonio") != null) {
			System.out.println("Encontrado: " + agenda.buscar("Antonio"));
		} else {
			System.out.println("Contacto no encontrado");
		}
		

	}

}
