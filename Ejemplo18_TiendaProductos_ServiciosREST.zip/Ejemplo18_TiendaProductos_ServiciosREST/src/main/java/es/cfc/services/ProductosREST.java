package es.cfc.services;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.json.JSONArray;
import org.json.JSONObject;

import es.cfc.business.ProductosBS;
import es.cfc.models.Producto;

@Path("/")
public class ProductosREST {
	
	private ProductosBS negocio = new ProductosBS();
	
	// http://localhost:8080/Ejemplo18_TiendaProductos_ServiciosREST/servlet/consultar
	@GET
	@Path("consultar")
	@Produces("application/json")
	public String todos() {
		List<Producto> lista = negocio.consultarTodos();
		JSONArray array = new JSONArray(lista);
		return array.toString();
	}
	
	// http://localhost:8080/Ejemplo18_TiendaProductos_ServiciosREST/servlet/eliminar/4
	@DELETE
	@Path("eliminar/{codigo}")
	@Produces("application/json")
	public String eliminar(@PathParam("codigo") int id) {
		JSONObject json = new JSONObject();
		json.put("eliminado", negocio.eliminarProducto(id));
		return json.toString();
	}
	
	// http://localhost:8080/Ejemplo18_TiendaProductos_ServiciosREST/servlet/alta
	@POST
	@Path("alta")
	@Produces("application/json")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public String alta(@FormParam("id") int id, 
					   @FormParam("descripcion") String descripcion, 
			           @FormParam("precio") double precio) {
		Producto nuevo = new Producto(id, descripcion, precio);
		JSONObject json = new JSONObject();
		json.put("insertado", negocio.altaProducto(nuevo));
		return json.toString();
	}
	
	

}
