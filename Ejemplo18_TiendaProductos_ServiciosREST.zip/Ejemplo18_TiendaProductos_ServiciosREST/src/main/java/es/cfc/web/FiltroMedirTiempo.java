package es.cfc.web;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpFilter;


@WebFilter("/tienda")
public class FiltroMedirTiempo extends HttpFilter implements Filter {
        
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) 
			throws IOException, ServletException {
		
		// Interceptamos la peticion
		long tiempoInicio = System.currentTimeMillis();
		System.out.println("Medido el tiempo de inicio");
		
		chain.doFilter(request, response);
		
		// Interceptamos la respuesta
		long tiempoFinal = System.currentTimeMillis();
		System.out.println("Medido el tiempo final");
		System.out.println("El tiempo transcurrido es " + (tiempoFinal - tiempoInicio) + " mseg.");
		
	}

	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}
	
	public void destroy() {
		// TODO Auto-generated method stub
	}

}
