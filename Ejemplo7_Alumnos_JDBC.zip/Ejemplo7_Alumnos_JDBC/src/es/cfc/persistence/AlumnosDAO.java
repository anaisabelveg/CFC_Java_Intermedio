package es.cfc.persistence;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import es.cfc.models.Alumno;

// DAO -> Data Access Object
public class AlumnosDAO {
	
	private Connection conexion;
	
	public void cambiarNota(int id, double nuevaNota) {
			
		try {
			abrirConexion();
			String sql = "update Estudiantes set NOTA = ? where ID = ?";
			PreparedStatement pst = conexion.prepareStatement(sql);
			pst.setDouble(1, nuevaNota);
			pst.setInt(2, id);
			int registro =  pst.executeUpdate();
					
		} catch (Exception e) {
			System.out.println("Error al modificar la nota");
			e.printStackTrace();
		} finally {
			cerrarConexion();
		}
	}
	
	public Alumno buscar(int id) {
		
		Alumno alumno = null;
		
		try {
			abrirConexion();
			String sql = "select * from Estudiantes where ID=?";
			
			PreparedStatement pst = conexion.prepareStatement(sql);
			pst.setInt(1, id);
			ResultSet rs = pst.executeQuery();
			
			if (rs.next()) {
				alumno = new Alumno(rs.getInt("ID"), 
						rs.getString("NOMBRE"), 
						rs.getString("APELLIDO"), 
						rs.getDouble("NOTA"));
			}
			
		} catch (Exception e) {
			System.out.println("No se puede buscar al alumno con id " + id);
			e.printStackTrace();
		} finally {
			cerrarConexion();
		}
		return alumno;
	}
	
	public boolean borrarAlumno(int id) {
		boolean borrado = false;
		
		try {
			abrirConexion();
			String sql = "delete from Estudiantes where ID=?";
			PreparedStatement pst = conexion.prepareStatement(sql);
			pst.setInt(1, id);
			int registros = pst.executeUpdate();
			
//			if (registros == 1) {
//				borrado = true;
//			}
			
			// Operador ternario
			borrado = (registros == 1) ? true : false;
			
		} catch (Exception e) {
			System.out.println("No se pudo eliminar el alumno con id " + id);
			e.printStackTrace();
		} finally {
			cerrarConexion();
		}
		return borrado;
	}
	
	public void altaAlumno(Alumno nuevo) {
		try {
			abrirConexion();
			
			String sql = "insert into Estudiantes values (?,?,?,?)";
			PreparedStatement pst = conexion.prepareStatement(sql);
			
			// Resolver los parametros
			pst.setInt(1, nuevo.getId());
			pst.setString(2, nuevo.getNombre());
			pst.setString(3, nuevo.getApellido());
			pst.setDouble(4, nuevo.getNota());
			
			int registros = pst.executeUpdate();
			
		} catch (Exception e) {
			System.out.println("Error al insertar el alumno " + nuevo);
			e.printStackTrace();
		} finally {
			cerrarConexion();
		}
	}
	
	
	public List<Alumno> consultarTodos(){
		List<Alumno> lista = new ArrayList<Alumno>();
		
		try {
			abrirConexion();
			
			String sql = "select * from Estudiantes";
			Statement stm = conexion.createStatement();
			ResultSet rs =  stm.executeQuery(sql);
			
			// Procesar los resultados obtenidos
			while (rs.next()) {
				lista.add(new Alumno(rs.getInt("ID"), 
						rs.getString("NOMBRE"), 
						rs.getString("APELLIDO"), 
						rs.getDouble("NOTA")));
			}
			
		} catch (Exception e) {
			System.out.println("Error al consultar todos los alumnos");
			e.printStackTrace();
		} finally {
			cerrarConexion();
		}
		
		return lista;
	}
	
	private void abrirConexion() {
			
		try {
			// Cargar el driver de la base de datos
			Class.forName("com.mysql.jdbc.Driver");
			
			// Abrir la conexion a la BBDD
			conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/Alumnos", 
					"root", "");
	
		} catch (ClassNotFoundException e) {
			System.out.println("No se encuentra el driver");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("Error al abrir la conexion");
			e.printStackTrace();
		}
		
	}
	
	private void cerrarConexion() {
		try {
			conexion.close();
		} catch (SQLException e) {
			System.out.println("Error al cerrar la conexion");
			e.printStackTrace();
		}
	}

}
