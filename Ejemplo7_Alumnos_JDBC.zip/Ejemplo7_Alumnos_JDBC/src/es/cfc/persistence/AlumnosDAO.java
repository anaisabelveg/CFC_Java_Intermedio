package es.cfc.persistence;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

// DAO -> Data Access Object
public class AlumnosDAO {
	
	private Connection conexion;
	
	private void abrirConexion() {
			
		try {
			// Cargar el driver de la base de datos
			Class.forName("com.mysql.jdbc.Driver");
			
			// Abrir la conexion a la BBDD
			conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/Alumnos", 
					"root", "");
	
		} catch (ClassNotFoundException e) {
			System.out.println("No se encuentra el driver");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("Error al abrir la conexion");
			e.printStackTrace();
		}
		
	}
	
	private void cerrarConexion() {
		try {
			conexion.close();
		} catch (SQLException e) {
			System.out.println("Error al cerrar la conexion");
			e.printStackTrace();
		}
	}

}
