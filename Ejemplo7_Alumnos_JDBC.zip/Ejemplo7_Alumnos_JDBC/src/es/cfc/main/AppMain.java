package es.cfc.main;

import es.cfc.models.Alumno;
import es.cfc.persistence.AlumnosDAO;

public class AppMain {

	public static void main(String[] args) {
		
		AlumnosDAO dao = new AlumnosDAO();
		
		// Borrar un alumno
		 if (dao.borrarAlumno(4)) {
			 System.out.println("Alumno eliminado");
		 } else {
			 System.out.println("Alumno no encontrado");
		 }
		
		// Insertar nuevo alumno
		dao.altaAlumno(new Alumno(4, "Pepito", "Perez", 1.5));
		
		// Modificar la nota a Pepito
		dao.cambiarNota(4, 5.0);
		
		// Consultar todos los alumnos
		for (Alumno alumno : dao.consultarTodos()) {
			System.out.println(alumno);
		}
		
		// Buscar un alumno
		System.out.println(dao.buscar(2));
		
		

	}

}
