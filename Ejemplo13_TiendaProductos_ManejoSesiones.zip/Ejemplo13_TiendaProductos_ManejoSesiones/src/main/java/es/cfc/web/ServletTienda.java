package es.cfc.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.cfc.business.ProductosBS;
import es.cfc.models.Producto;


@WebServlet("/tienda")
public class ServletTienda extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private ProductosBS negocio = new ProductosBS();
    
	private String procesarAlta(HttpServletRequest request, 
				HttpServletResponse response) {
		Producto nuevo = new Producto(
				Integer.parseInt(request.getParameter("codigo")), 
				request.getParameter("desc"), 
				Double.parseDouble(request.getParameter("precio")));
		
		 if (negocio.altaProducto(nuevo)) {
			 request.setAttribute("mensaje", "Producto insertado correctamente");
		 } else {
			 request.setAttribute("mensaje", "No se pudo insertar el producto");
		 }
			 
		
		return "/mostrarMensaje.jsp";
	}
    
	private String procesarTodos(HttpServletRequest request, 
			HttpServletResponse response) {
		request.setAttribute("lista", negocio.consultarTodos());
		return "/mostrarTodos.jsp";
	}
	
	private String procesarBuscarDescripcion(HttpServletRequest request, 
			HttpServletResponse response) {
		request.setAttribute("lista", 
				negocio.buscarPorDescripcion(request.getParameter("desc")));
		return "/mostrarTodos.jsp";
	}
	
	private String procesarModificar(HttpServletRequest request, 
			HttpServletResponse response) {
		boolean modificado = negocio.cambiarPrecio(
				Integer.parseInt(request.getParameter("codigo")),
				Double.parseDouble(request.getParameter("precio")));
		
		if (modificado) {
			request.setAttribute("mensaje", "Producto modificado");
		} else {
			request.setAttribute("mensaje", "No se pudo modificar el producto");
		}
		
		return "/mostrarMensaje.jsp";
	}
	
	private String procesarBorrar(HttpServletRequest request, 
			HttpServletResponse response) {
		boolean eliminado = 
				negocio.eliminarProducto(
						Integer.parseInt(request.getParameter("codigo")));
		if (eliminado) {
			request.setAttribute("mensaje", "Producto eliminado");
		} else {
			request.setAttribute("mensaje", "No se pudo eliminar el producto");
		}
		
		return "/mostrarMensaje.jsp";
	}
	
	private String procesarBuscarId(HttpServletRequest request, 
			HttpServletResponse response) {
		Producto encontrado = negocio.buscarPorId(
				Integer.parseInt(request.getParameter("codigo")));
		request.setAttribute("encontrado", encontrado);
		return "/mostrarProducto.jsp";
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String pagina = "/index.jsp";
		
		switch (request.getParameter("opcion")) {
		case "alta":
			pagina = procesarAlta(request, response);
			break;
		
		case "todos":
			pagina = procesarTodos(request, response);
			break;
			
		case "buscarDesc":
			pagina = procesarBuscarDescripcion(request, response);
			break;
			
		case "modificar":
			pagina = procesarModificar(request, response);
			break;
			
		case "borrar":
			pagina = procesarBorrar(request, response);
			break;
			
		case "buscarId":
			pagina = procesarBuscarId(request, response);
			break;
			
		default:
			break;
		}
		
		RequestDispatcher rd = request.getRequestDispatcher(pagina);
		rd.forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
