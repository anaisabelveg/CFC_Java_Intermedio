package es.cfc.business;

import java.util.HashSet;
import java.util.Set;

import es.cfc.models.Producto;

public class Carrito {
	
	private double importe = 0;
	private Set<Producto> contenido = new HashSet<Producto>();
	
	public void addProducto(int id) {
		ProductosBS negocio = new ProductosBS();
		Producto encontrado = negocio.buscarPorId(id);
		contenido.add(encontrado);
		importe += encontrado.getPrecio();
	}
	
	public void sacarProducto(int id) {
		Producto encontrado = null;
		for (Producto producto : contenido) {
			if (id == producto.getId()) {
				encontrado = producto;
				break;
			}
		}
		contenido.remove(encontrado);
		importe -= encontrado.getPrecio();
	}
	
	public double getImporte() {
		return importe;
	}
	public Set<Producto> getContenido() {
		return contenido;
	}
	
	

}
