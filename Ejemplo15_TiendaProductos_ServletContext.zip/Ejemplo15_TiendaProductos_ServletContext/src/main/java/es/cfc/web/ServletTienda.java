package es.cfc.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import es.cfc.business.Carrito;
import es.cfc.business.ProductosBS;
import es.cfc.models.Producto;


@WebServlet(urlPatterns = {"/tienda"}, 
	initParams = {@WebInitParam(name = "Oferta", value= "Hoy 10% de descuento en todos los productos")})
public class ServletTienda extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private ProductosBS negocio = new ProductosBS();
	
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		
		System.out.println("La instancia del servlet se acaba de crear");
		
		// Recuperar el parametro con nombre Oferta
		String msgOferta = config.getInitParameter("Oferta");
		
		// Guardar el mensaje como atributo de la aplicacion
		ServletContext ctxApp = config.getServletContext();
		ctxApp.setAttribute("msgOferta", msgOferta);
		
	}
	

	@Override
	public void destroy() {
		super.destroy();
		
		System.out.println("La instancia del servlet se va a destruir");
		
	}


	private String procesarAlta(HttpServletRequest request, 
				HttpServletResponse response) {
		Producto nuevo = new Producto(
				Integer.parseInt(request.getParameter("codigo")), 
				request.getParameter("desc"), 
				Double.parseDouble(request.getParameter("precio")));
		
		 if (negocio.altaProducto(nuevo)) {
			 request.setAttribute("mensaje", "Producto insertado correctamente");
		 } else {
			 request.setAttribute("mensaje", "No se pudo insertar el producto");
		 }
			 
		
		return "/mostrarMensaje.jsp";
	}
    
	private String procesarTodos(HttpServletRequest request, 
			HttpServletResponse response) {
		request.setAttribute("lista", negocio.consultarTodos());
		return "/mostrarTodos.jsp";
	}
	
	private String procesarBuscarDescripcion(HttpServletRequest request, 
			HttpServletResponse response) {
		request.setAttribute("lista", 
				negocio.buscarPorDescripcion(request.getParameter("desc")));
		return "/mostrarTodos.jsp";
	}
	
	private String procesarModificar(HttpServletRequest request, 
			HttpServletResponse response) {
		boolean modificado = negocio.cambiarPrecio(
				Integer.parseInt(request.getParameter("codigo")),
				Double.parseDouble(request.getParameter("precio")));
		
		if (modificado) {
			request.setAttribute("mensaje", "Producto modificado");
		} else {
			request.setAttribute("mensaje", "No se pudo modificar el producto");
		}
		
		return "/mostrarMensaje.jsp";
	}
	
	private String procesarBorrar(HttpServletRequest request, 
			HttpServletResponse response) {
		boolean eliminado = 
				negocio.eliminarProducto(
						Integer.parseInt(request.getParameter("codigo")));
		if (eliminado) {
			request.setAttribute("mensaje", "Producto eliminado");
		} else {
			request.setAttribute("mensaje", "No se pudo eliminar el producto");
		}
		
		return "/mostrarMensaje.jsp";
	}
	
	private String procesarBuscarId(HttpServletRequest request, 
			HttpServletResponse response) {
		Producto encontrado = negocio.buscarPorId(
				Integer.parseInt(request.getParameter("codigo")));
		request.setAttribute("encontrado", encontrado);
		return "/mostrarProducto.jsp";
	}
	
	private String procesarComprar(HttpServletRequest request, 
			HttpServletResponse response) {
		// Recuperar o crear la sesion del usuario
		// request.getSession(true) = request.getSession();
		HttpSession miSesion = request.getSession(true);
		
		// Recuperamos el atributo miCarro
		Carrito carrito = (Carrito) miSesion.getAttribute("miCarro");
		
		// Si acabamos de crear la sesion y no tenemos el carrito, lo creamos
		if (carrito == null) {
			carrito = new Carrito();
			miSesion.setAttribute("miCarro", carrito);
		}
		
		// Agregar el producto al carrito
		carrito.addProducto(Integer.parseInt(request.getParameter("codigo")));
		
		return "/mostrarCarrito.jsp";
	}
	
	private String procesarSacar(HttpServletRequest request, 
			HttpServletResponse response) {
		// Recuperar la sesion del usuario y si no existe no la cree
		HttpSession miSesion = request.getSession(false);
		
		// Recuperamos el atributo miCarro
		Carrito carrito = (Carrito) miSesion.getAttribute("miCarro");
		
		// sacar el producto
		carrito.sacarProducto(Integer.parseInt(request.getParameter("codigo")));
		
		return "/mostrarCarrito.jsp";
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String pagina = "/index.jsp";
		
		switch (request.getParameter("opcion")) {
		case "alta":
			pagina = procesarAlta(request, response);
			break;
		
		case "todos":
			pagina = procesarTodos(request, response);
			break;
			
		case "buscarDesc":
			pagina = procesarBuscarDescripcion(request, response);
			break;
			
		case "modificar":
			pagina = procesarModificar(request, response);
			break;
			
		case "borrar":
			pagina = procesarBorrar(request, response);
			break;
			
		case "buscarId":
			pagina = procesarBuscarId(request, response);
			break;
			
		case "comprar":
			pagina = procesarComprar(request, response);
			break;
			
		case "sacar":
			pagina = procesarSacar(request, response);
			break;
			
		
		default:
			break;
		}
		
		RequestDispatcher rd = request.getRequestDispatcher(pagina);
		rd.forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
