package es.cfc.util;

import java.util.Comparator;

import es.cfc.models.Contacto;

public class ComparadorNombre implements Comparator<Contacto>{

	@Override
	public int compare(Contacto contacto1, Contacto contacto2) {
		// TODO Auto-generated method stub
		return contacto1.getNombre().compareTo(contacto2.getNombre());
	}

}
