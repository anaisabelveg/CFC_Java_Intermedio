package es.cfc.business;

import java.util.Set;
import java.util.TreeSet;

import es.cfc.models.Contacto;
import es.cfc.util.ComparadorNombre;

public class Agenda {

	// ctrl + shift + o
	private Set<Contacto> misContactos = new TreeSet<>(new ComparadorNombre());

	public Set<Contacto> verTodos() {
		return misContactos;
	}

	public void agregarContacto(Contacto contacto) {
		misContactos.add(contacto);
//		if (contador < 10) {
//			misContactos[contador] = contacto;
//			contador++;
//		} else {
//			System.out.println("No se admiten mas de 10 contactos");
//		}
	}

	public Contacto buscar(String nombre) {
		Contacto encontrado = null;

		for (Contacto aux : misContactos) {
			if (nombre.equals(aux.getNombre())) {
				encontrado = aux;
				break;
			}
		}

		return encontrado;
	}

}
