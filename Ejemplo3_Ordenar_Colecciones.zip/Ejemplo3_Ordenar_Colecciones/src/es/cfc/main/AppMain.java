package es.cfc.main;

import java.util.Comparator;
import java.util.Set;
import java.util.TreeSet;

import es.cfc.models.Alumno;
import es.cfc.models.AlumnoComparable;
import es.cfc.util.NombreComparator;
import es.cfc.util.NotaComparator;

public class AppMain {

	public static void main(String[] args) {
		
		//ctrl + shift + o
		Set<AlumnoComparable> alumnos = new TreeSet<AlumnoComparable>();
		alumnos.add(new AlumnoComparable("Juan", "Garcia", 6.9));
		alumnos.add(new AlumnoComparable("Maria", "Sanz", 3.9));
		alumnos.add(new AlumnoComparable("Laura", "Rodriguez", 8.2));
		alumnos.add(new AlumnoComparable("Luis", "Sanchez", 5.2));
		alumnos.add(new AlumnoComparable("Jorge", "Arias", 5.2));
		alumnos.add(new AlumnoComparable("Antonio", "Alonso", 6.8));
		
		for (AlumnoComparable alumno : alumnos) {
			System.out.println(alumno);
		}
		
		Comparator<Alumno> compNota = new NotaComparator();
		Set<Alumno> alumnosNota = new TreeSet<Alumno>(compNota);
		alumnosNota.add(new Alumno("Juan", "Garcia", 6.9));
		alumnosNota.add(new Alumno("Maria", "Sanz", 3.9));
		alumnosNota.add(new Alumno("Laura", "Rodriguez", 8.2));
		alumnosNota.add(new Alumno("Luis", "Sanchez", 5.2));
		alumnosNota.add(new Alumno("Jorge", "Arias", 5.2));
		alumnosNota.add(new Alumno("Antonio", "Alonso", 6.8));
		
		for (Alumno alumno : alumnosNota) {
			System.out.println(alumno);
		}
		
		
		// ordenar por nombre
		Set<Alumno> alumnosNombre = new TreeSet<Alumno>(new NombreComparator());
		alumnosNombre.add(new Alumno("Juan", "Garcia", 6.9));
		alumnosNombre.add(new Alumno("Maria", "Sanz", 3.9));
		alumnosNombre.add(new Alumno("Laura", "Rodriguez", 8.2));
		alumnosNombre.add(new Alumno("Luis", "Sanchez", 5.2));
		alumnosNombre.add(new Alumno("Jorge", "Arias", 5.2));
		alumnosNombre.add(new Alumno("Antonio", "Alonso", 6.8));
		
		for (Alumno alumno : alumnosNombre) {
			System.out.println(alumno);
		}
		

	}

}
