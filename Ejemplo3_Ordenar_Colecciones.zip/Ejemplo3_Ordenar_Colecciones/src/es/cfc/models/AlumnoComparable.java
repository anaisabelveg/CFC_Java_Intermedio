package es.cfc.models;

public class AlumnoComparable implements Comparable<AlumnoComparable>{
	
	private String nombre;
	private String apellido;
	private double nota;
	
	public AlumnoComparable() {
		// TODO Auto-generated constructor stub
	}

	public AlumnoComparable(String nombre, String apellido, double nota) {
		super();
		this.nombre = nombre;
		this.apellido = apellido;
		this.nota = nota;
	}
	
	@Override
	public int compareTo(AlumnoComparable otro) {
		// 1 -> si la instancia es mayor que el alumno recibido
		// -1 -> si la instancia es menor que el alumno recibido
		// 0 -> si son iguales
		
		if (nota > otro.getNota()) {
			return 1;
		} else if (nota < otro.getNota()) {
			return -1;
		} else {
			return 0;
		}
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public double getNota() {
		return nota;
	}

	public void setNota(double nota) {
		this.nota = nota;
	}

	@Override
	public String toString() {
		return "Alumno [nombre=" + nombre + ", apellido=" + apellido + ", nota=" + nota + "]";
	}

	
	
	

}
