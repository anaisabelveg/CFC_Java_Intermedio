package es.cfc.util;

import java.util.Comparator;

import es.cfc.models.Alumno;

public class NotaComparator implements Comparator<Alumno>{

	@Override
	public int compare(Alumno alum1, Alumno alum2) {
		if (alum1.getNota() > alum2.getNota()) {
			return 1;
		} else if (alum1.getNota() < alum2.getNota()) {
			return -1;
		} else {
			return alum1.getNombre().compareTo(alum2.getNombre());
		}
	}

}
