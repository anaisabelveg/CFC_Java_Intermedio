package es.cfc.util;

import java.util.Comparator;

import es.cfc.models.Alumno;

public class NombreComparator implements Comparator<Alumno>{

	@Override
	public int compare(Alumno alum1, Alumno alum2) {
		return alum1.getNombre().compareTo(alum2.getNombre());
	}

}
