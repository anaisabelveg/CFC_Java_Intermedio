package es.cfc;

public class AppMain {
	
	public static void main(String[] args) {
		
		int edad = -16;
		
		// Si la condicion no es true genera un AssertionError
		// Las asserciones estan deshabilitadas por defecto
		// sobre el proyecto, boton dcho, Run as ..., Run configurations
		// pestaña arguments, en Options VM poner -ea
		assert (edad >= 0) : "Error, la edad nunca puede ser negativa";
		
		if (edad >= 18) {
			System.out.println("Eres mayor de edad");
		} else {
			System.out.println("Eres un menor");
		}
		
	}

}
