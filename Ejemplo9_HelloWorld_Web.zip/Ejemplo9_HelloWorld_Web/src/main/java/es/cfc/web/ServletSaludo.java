package es.cfc.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/saludo")
public class ServletSaludo extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	// Se ejecuta cuando la peticion llega por el metodo GET
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// opcion 1 -> mostrar el mensaje en la misma pagina
		response.getWriter().print("Hola desde el Servlet ");
		
		
		// opcion 2 -> mostrar el mensaje en otra pagina
		// Recuperar el parametro nombre
		// Todos los valores recibidos en parametros son String
		String nombreUsuario = request.getParameter("nombre");
		
		String mensaje = "Hola " + nombreUsuario + " desde el Servlet ";
		// Eligir que pagina mostrara el mensaje
		RequestDispatcher rd = 
				request.getRequestDispatcher("/mostrarRespuesta.jsp");
		// Adjuntamos el mensaje a mostrar
		request.setAttribute("msg", mensaje);
		// Reenviar
		rd.forward(request, response);
	}

	// Se ejecuta cuando la peticion llega por el metodo POST
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
